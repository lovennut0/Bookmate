﻿namespace bookmate
{
    partial class cart
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.shop = new System.Windows.Forms.GroupBox();
            this.bookname3 = new System.Windows.Forms.Label();
            this.bookname1 = new System.Windows.Forms.Label();
            this.id3 = new System.Windows.Forms.Label();
            this.id1 = new System.Windows.Forms.Label();
            this.picBox3cart = new System.Windows.Forms.PictureBox();
            this.pic2cart = new System.Windows.Forms.PictureBox();
            this.drop1 = new System.Windows.Forms.Button();
            this.logoutcart = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.backcart = new System.Windows.Forms.Button();
            this.payment = new System.Windows.Forms.Button();
            this.shop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBox3cart)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic2cart)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // shop
            // 
            this.shop.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.shop.Controls.Add(this.bookname3);
            this.shop.Controls.Add(this.bookname1);
            this.shop.Controls.Add(this.id3);
            this.shop.Controls.Add(this.id1);
            this.shop.Controls.Add(this.picBox3cart);
            this.shop.Controls.Add(this.pic2cart);
            this.shop.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.shop.Location = new System.Drawing.Point(8, 36);
            this.shop.Margin = new System.Windows.Forms.Padding(2);
            this.shop.Name = "shop";
            this.shop.Padding = new System.Windows.Forms.Padding(2);
            this.shop.Size = new System.Drawing.Size(542, 285);
            this.shop.TabIndex = 5;
            this.shop.TabStop = false;
            this.shop.Text = "CART";
            // 
            // bookname3
            // 
            this.bookname3.AutoSize = true;
            this.bookname3.Location = new System.Drawing.Point(312, 186);
            this.bookname3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.bookname3.Name = "bookname3";
            this.bookname3.Size = new System.Drawing.Size(130, 16);
            this.bookname3.TabIndex = 14;
            this.bookname3.Text = "Book Name : COMIC";
            // 
            // bookname1
            // 
            this.bookname1.AutoSize = true;
            this.bookname1.Location = new System.Drawing.Point(312, 67);
            this.bookname1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.bookname1.Name = "bookname1";
            this.bookname1.Size = new System.Drawing.Size(182, 16);
            this.bookname1.TabIndex = 12;
            this.bookname1.Text = "Book Name : Intro to Science ";
            this.bookname1.UseWaitCursor = true;
            // 
            // id3
            // 
            this.id3.AutoSize = true;
            this.id3.Location = new System.Drawing.Point(169, 186);
            this.id3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.id3.Name = "id3";
            this.id3.Size = new System.Drawing.Size(57, 16);
            this.id3.TabIndex = 10;
            this.id3.Text = "ID : 1003";
            // 
            // id1
            // 
            this.id1.AutoSize = true;
            this.id1.Location = new System.Drawing.Point(169, 67);
            this.id1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.id1.Name = "id1";
            this.id1.Size = new System.Drawing.Size(57, 16);
            this.id1.TabIndex = 8;
            this.id1.Text = "ID : 1001";
            // 
            // picBox3cart
            // 
            this.picBox3cart.Image = global::bookmate.Properties.Resources.comic;
            this.picBox3cart.Location = new System.Drawing.Point(35, 145);
            this.picBox3cart.Margin = new System.Windows.Forms.Padding(2);
            this.picBox3cart.Name = "picBox3cart";
            this.picBox3cart.Size = new System.Drawing.Size(89, 95);
            this.picBox3cart.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBox3cart.TabIndex = 2;
            this.picBox3cart.TabStop = false;
            // 
            // pic2cart
            // 
            this.pic2cart.Image = global::bookmate.Properties.Resources.sci;
            this.pic2cart.Location = new System.Drawing.Point(32, 35);
            this.pic2cart.Margin = new System.Windows.Forms.Padding(2);
            this.pic2cart.Name = "pic2cart";
            this.pic2cart.Size = new System.Drawing.Size(97, 91);
            this.pic2cart.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic2cart.TabIndex = 0;
            this.pic2cart.TabStop = false;
            // 
            // drop1
            // 
            this.drop1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.drop1.Location = new System.Drawing.Point(692, 153);
            this.drop1.Margin = new System.Windows.Forms.Padding(2);
            this.drop1.Name = "drop1";
            this.drop1.Size = new System.Drawing.Size(137, 44);
            this.drop1.TabIndex = 4;
            this.drop1.Text = "Drop";
            this.drop1.UseVisualStyleBackColor = false;
            // 
            // logoutcart
            // 
            this.logoutcart.Location = new System.Drawing.Point(984, 250);
            this.logoutcart.Margin = new System.Windows.Forms.Padding(2);
            this.logoutcart.Name = "logoutcart";
            this.logoutcart.Size = new System.Drawing.Size(123, 26);
            this.logoutcart.TabIndex = 4;
            this.logoutcart.Text = "Log out";
            this.logoutcart.UseVisualStyleBackColor = true;
            this.logoutcart.Click += new System.EventHandler(this.logoutcart_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.pictureBox1.Image = global::bookmate.Properties.Resources.images;
            this.pictureBox1.Location = new System.Drawing.Point(933, 13);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(225, 225);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // backcart
            // 
            this.backcart.Location = new System.Drawing.Point(31, 470);
            this.backcart.Margin = new System.Windows.Forms.Padding(2);
            this.backcart.Name = "backcart";
            this.backcart.Size = new System.Drawing.Size(88, 33);
            this.backcart.TabIndex = 6;
            this.backcart.Text = "< BACK";
            this.backcart.UseVisualStyleBackColor = true;
            this.backcart.Click += new System.EventHandler(this.backcart_Click);
            // 
            // payment
            // 
            this.payment.Location = new System.Drawing.Point(1043, 470);
            this.payment.Margin = new System.Windows.Forms.Padding(2);
            this.payment.Name = "payment";
            this.payment.Size = new System.Drawing.Size(88, 33);
            this.payment.TabIndex = 7;
            this.payment.Text = "PAYMENT ";
            this.payment.UseVisualStyleBackColor = true;
            this.payment.Click += new System.EventHandler(this.payment_Click);
            // 
            // cart
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1169, 540);
            this.Controls.Add(this.payment);
            this.Controls.Add(this.backcart);
            this.Controls.Add(this.shop);
            this.Controls.Add(this.logoutcart);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.drop1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "cart";
            this.Text = "cart";
            this.Load += new System.EventHandler(this.cart_Load);
            this.shop.ResumeLayout(false);
            this.shop.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBox3cart)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic2cart)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox shop;
        private System.Windows.Forms.Label bookname3;
        private System.Windows.Forms.Label bookname1;
        private System.Windows.Forms.Label id3;
        private System.Windows.Forms.Label id1;
        private System.Windows.Forms.Button drop1;
        private System.Windows.Forms.PictureBox picBox3cart;
        private System.Windows.Forms.PictureBox pic2cart;
        private System.Windows.Forms.Button logoutcart;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button backcart;
        private System.Windows.Forms.Button payment;
    }
}