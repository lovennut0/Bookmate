﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bookmate
{
    public partial class Starting : Form
    {
        public Starting()
        {
            InitializeComponent();
        }

        private void CreateAccountbutton_Click(object sender, EventArgs e)
        {
            this.Hide();
            signup sign = new signup();
            sign.StartPosition = FormStartPosition.Manual;
            sign.Location = this.Location;
            sign.Show();
        }

        private void login_Click(object sender, EventArgs e)
        {
            this.Hide();
            loginpage login = new loginpage();
            login.StartPosition = FormStartPosition.Manual;
            login.Location = this.Location;
            login.Show();
        }
    }
}
