﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bookmate
{
    public partial class shop : Form
    {
        public shop()
        {
            InitializeComponent();
        }

        private void shop_Load(object sender, EventArgs e)
        {

        }

        private void Logout_Click(object sender, EventArgs e)
        {
            this.Hide();
            Starting start = new Starting();
            start.StartPosition = FormStartPosition.Manual;
            start.Location = this.Location;
            start.Show();
        }
    }
}
