﻿namespace bookmate
{
    partial class shop
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.nextbut = new System.Windows.Forms.Button();
            this.booklist = new System.Windows.Forms.GroupBox();
            this.bookname4 = new System.Windows.Forms.Label();
            this.bookname3 = new System.Windows.Forms.Label();
            this.bookname2 = new System.Windows.Forms.Label();
            this.bookname1 = new System.Windows.Forms.Label();
            this.id4 = new System.Windows.Forms.Label();
            this.id3 = new System.Windows.Forms.Label();
            this.id2 = new System.Windows.Forms.Label();
            this.id1 = new System.Windows.Forms.Label();
            this.add4 = new System.Windows.Forms.Button();
            this.add3 = new System.Windows.Forms.Button();
            this.add2 = new System.Windows.Forms.Button();
            this.add1 = new System.Windows.Forms.Button();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.Logout = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.booklist.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // nextbut
            // 
            this.nextbut.Location = new System.Drawing.Point(955, 481);
            this.nextbut.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.nextbut.Name = "nextbut";
            this.nextbut.Size = new System.Drawing.Size(123, 26);
            this.nextbut.TabIndex = 7;
            this.nextbut.Text = "Next >";
            this.nextbut.UseVisualStyleBackColor = true;
            // 
            // booklist
            // 
            this.booklist.Controls.Add(this.bookname4);
            this.booklist.Controls.Add(this.bookname3);
            this.booklist.Controls.Add(this.bookname2);
            this.booklist.Controls.Add(this.bookname1);
            this.booklist.Controls.Add(this.id4);
            this.booklist.Controls.Add(this.id3);
            this.booklist.Controls.Add(this.id2);
            this.booklist.Controls.Add(this.id1);
            this.booklist.Controls.Add(this.add4);
            this.booklist.Controls.Add(this.add3);
            this.booklist.Controls.Add(this.add2);
            this.booklist.Controls.Add(this.add1);
            this.booklist.Controls.Add(this.pictureBox5);
            this.booklist.Controls.Add(this.pictureBox4);
            this.booklist.Controls.Add(this.pictureBox3);
            this.booklist.Controls.Add(this.pictureBox2);
            this.booklist.Location = new System.Drawing.Point(1, 37);
            this.booklist.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.booklist.Name = "booklist";
            this.booklist.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.booklist.Size = new System.Drawing.Size(914, 483);
            this.booklist.TabIndex = 6;
            this.booklist.TabStop = false;
            this.booklist.Text = "SHOP";
            // 
            // bookname4
            // 
            this.bookname4.AutoSize = true;
            this.bookname4.Location = new System.Drawing.Point(312, 397);
            this.bookname4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.bookname4.Name = "bookname4";
            this.bookname4.Size = new System.Drawing.Size(194, 16);
            this.bookname4.TabIndex = 15;
            this.bookname4.Text = "Book Name : English for Writing";
            // 
            // bookname3
            // 
            this.bookname3.AutoSize = true;
            this.bookname3.Location = new System.Drawing.Point(312, 281);
            this.bookname3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.bookname3.Name = "bookname3";
            this.bookname3.Size = new System.Drawing.Size(130, 16);
            this.bookname3.TabIndex = 14;
            this.bookname3.Text = "Book Name : COMIC";
            // 
            // bookname2
            // 
            this.bookname2.AutoSize = true;
            this.bookname2.Location = new System.Drawing.Point(312, 172);
            this.bookname2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.bookname2.Name = "bookname2";
            this.bookname2.Size = new System.Drawing.Size(157, 16);
            this.bookname2.TabIndex = 13;
            this.bookname2.Text = "Book Name : Mathematic";
            // 
            // bookname1
            // 
            this.bookname1.AutoSize = true;
            this.bookname1.Location = new System.Drawing.Point(312, 67);
            this.bookname1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.bookname1.Name = "bookname1";
            this.bookname1.Size = new System.Drawing.Size(182, 16);
            this.bookname1.TabIndex = 12;
            this.bookname1.Text = "Book Name : Intro to Science ";
            this.bookname1.UseWaitCursor = true;
            // 
            // id4
            // 
            this.id4.AutoSize = true;
            this.id4.Location = new System.Drawing.Point(169, 397);
            this.id4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.id4.Name = "id4";
            this.id4.Size = new System.Drawing.Size(57, 16);
            this.id4.TabIndex = 11;
            this.id4.Text = "ID : 1004";
            // 
            // id3
            // 
            this.id3.AutoSize = true;
            this.id3.Location = new System.Drawing.Point(169, 281);
            this.id3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.id3.Name = "id3";
            this.id3.Size = new System.Drawing.Size(57, 16);
            this.id3.TabIndex = 10;
            this.id3.Text = "ID : 1003";
            // 
            // id2
            // 
            this.id2.AutoSize = true;
            this.id2.Cursor = System.Windows.Forms.Cursors.PanNW;
            this.id2.Location = new System.Drawing.Point(169, 172);
            this.id2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.id2.Name = "id2";
            this.id2.Size = new System.Drawing.Size(57, 16);
            this.id2.TabIndex = 9;
            this.id2.Text = "ID : 1002";
            // 
            // id1
            // 
            this.id1.AutoSize = true;
            this.id1.Location = new System.Drawing.Point(169, 67);
            this.id1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.id1.Name = "id1";
            this.id1.Size = new System.Drawing.Size(57, 16);
            this.id1.TabIndex = 8;
            this.id1.Text = "ID : 1001";
            // 
            // add4
            // 
            this.add4.Location = new System.Drawing.Point(743, 397);
            this.add4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.add4.Name = "add4";
            this.add4.Size = new System.Drawing.Size(137, 44);
            this.add4.TabIndex = 7;
            this.add4.Text = "add ";
            this.add4.UseVisualStyleBackColor = true;
            // 
            // add3
            // 
            this.add3.Location = new System.Drawing.Point(743, 281);
            this.add3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.add3.Name = "add3";
            this.add3.Size = new System.Drawing.Size(137, 44);
            this.add3.TabIndex = 6;
            this.add3.Text = "add ";
            this.add3.UseVisualStyleBackColor = true;
            // 
            // add2
            // 
            this.add2.Location = new System.Drawing.Point(743, 172);
            this.add2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.add2.Name = "add2";
            this.add2.Size = new System.Drawing.Size(137, 44);
            this.add2.TabIndex = 5;
            this.add2.Text = "add ";
            this.add2.UseVisualStyleBackColor = true;
            // 
            // add1
            // 
            this.add1.Location = new System.Drawing.Point(743, 67);
            this.add1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.add1.Name = "add1";
            this.add1.Size = new System.Drawing.Size(137, 44);
            this.add1.TabIndex = 4;
            this.add1.Text = "add ";
            this.add1.UseVisualStyleBackColor = true;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::bookmate.Properties.Resources.images__1_;
            this.pictureBox5.Location = new System.Drawing.Point(40, 360);
            this.pictureBox5.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(85, 98);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 3;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::bookmate.Properties.Resources.comic;
            this.pictureBox4.Location = new System.Drawing.Point(35, 243);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(89, 95);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 2;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::bookmate.Properties.Resources.math;
            this.pictureBox3.Location = new System.Drawing.Point(35, 138);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(93, 88);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 1;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::bookmate.Properties.Resources.sci;
            this.pictureBox2.Location = new System.Drawing.Point(32, 35);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(97, 91);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // Logout
            // 
            this.Logout.Location = new System.Drawing.Point(990, 237);
            this.Logout.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Logout.Name = "Logout";
            this.Logout.Size = new System.Drawing.Size(123, 26);
            this.Logout.TabIndex = 5;
            this.Logout.Text = "Log out";
            this.Logout.UseVisualStyleBackColor = true;
            this.Logout.Click += new System.EventHandler(this.Logout_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.pictureBox1.Image = global::bookmate.Properties.Resources.images;
            this.pictureBox1.Location = new System.Drawing.Point(938, 4);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(225, 225);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // shop
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1179, 529);
            this.Controls.Add(this.nextbut);
            this.Controls.Add(this.booklist);
            this.Controls.Add(this.Logout);
            this.Controls.Add(this.pictureBox1);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "shop";
            this.Text = "shop";
            this.Load += new System.EventHandler(this.shop_Load);
            this.booklist.ResumeLayout(false);
            this.booklist.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button nextbut;
        private System.Windows.Forms.GroupBox booklist;
        private System.Windows.Forms.Label bookname4;
        private System.Windows.Forms.Label bookname3;
        private System.Windows.Forms.Label bookname2;
        private System.Windows.Forms.Label bookname1;
        private System.Windows.Forms.Label id4;
        private System.Windows.Forms.Label id3;
        private System.Windows.Forms.Label id2;
        private System.Windows.Forms.Label id1;
        private System.Windows.Forms.Button add4;
        private System.Windows.Forms.Button add3;
        private System.Windows.Forms.Button add2;
        private System.Windows.Forms.Button add1;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button Logout;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}