﻿namespace bookmate
{
    partial class last
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.logoutlastpg = new System.Windows.Forms.Button();
            this.inventory = new System.Windows.Forms.Button();
            this.complete = new System.Windows.Forms.Label();
            this.gotoshop = new System.Windows.Forms.Button();
            this.picuser = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picuser)).BeginInit();
            this.SuspendLayout();
            // 
            // logoutlastpg
            // 
            this.logoutlastpg.Location = new System.Drawing.Point(957, 240);
            this.logoutlastpg.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.logoutlastpg.Name = "logoutlastpg";
            this.logoutlastpg.Size = new System.Drawing.Size(123, 26);
            this.logoutlastpg.TabIndex = 6;
            this.logoutlastpg.Text = "Log out";
            this.logoutlastpg.UseVisualStyleBackColor = true;
            this.logoutlastpg.Click += new System.EventHandler(this.logoutlastpg_Click);
            // 
            // inventory
            // 
            this.inventory.Location = new System.Drawing.Point(19, 477);
            this.inventory.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.inventory.Name = "inventory";
            this.inventory.Size = new System.Drawing.Size(123, 26);
            this.inventory.TabIndex = 7;
            this.inventory.Text = "Inventory";
            this.inventory.UseVisualStyleBackColor = true;
            // 
            // complete
            // 
            this.complete.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.complete.ForeColor = System.Drawing.Color.Olive;
            this.complete.Location = new System.Drawing.Point(181, 167);
            this.complete.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.complete.Name = "complete";
            this.complete.Size = new System.Drawing.Size(714, 136);
            this.complete.TabIndex = 10;
            this.complete.Text = "Purchase Complete!!";
            this.complete.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gotoshop
            // 
            this.gotoshop.Location = new System.Drawing.Point(940, 477);
            this.gotoshop.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.gotoshop.Name = "gotoshop";
            this.gotoshop.Size = new System.Drawing.Size(123, 26);
            this.gotoshop.TabIndex = 11;
            this.gotoshop.Text = "Go to shop";
            this.gotoshop.UseVisualStyleBackColor = true;
            this.gotoshop.Click += new System.EventHandler(this.button2_Click);
            // 
            // picuser
            // 
            this.picuser.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.picuser.Image = global::bookmate.Properties.Resources.images;
            this.picuser.Location = new System.Drawing.Point(899, 11);
            this.picuser.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.picuser.Name = "picuser";
            this.picuser.Size = new System.Drawing.Size(225, 225);
            this.picuser.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picuser.TabIndex = 5;
            this.picuser.TabStop = false;
            // 
            // last
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1135, 531);
            this.Controls.Add(this.gotoshop);
            this.Controls.Add(this.complete);
            this.Controls.Add(this.inventory);
            this.Controls.Add(this.logoutlastpg);
            this.Controls.Add(this.picuser);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "last";
            this.Text = "last";
            ((System.ComponentModel.ISupportInitialize)(this.picuser)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button logoutlastpg;
        private System.Windows.Forms.PictureBox picuser;
        private System.Windows.Forms.Button inventory;
        private System.Windows.Forms.Label complete;
        private System.Windows.Forms.Button gotoshop;
    }
}