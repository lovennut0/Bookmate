﻿namespace bookmate
{
    partial class Starting
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CreateAccountbutton = new System.Windows.Forms.Button();
            this.bookmatepanel1 = new System.Windows.Forms.Panel();
            this.Bookmate = new System.Windows.Forms.Label();
            this.login = new System.Windows.Forms.Button();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.bookmatepanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // CreateAccountbutton
            // 
            this.CreateAccountbutton.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.CreateAccountbutton.Location = new System.Drawing.Point(465, 425);
            this.CreateAccountbutton.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.CreateAccountbutton.Name = "CreateAccountbutton";
            this.CreateAccountbutton.Size = new System.Drawing.Size(181, 44);
            this.CreateAccountbutton.TabIndex = 9;
            this.CreateAccountbutton.Text = "Create Account";
            this.CreateAccountbutton.UseVisualStyleBackColor = false;
            this.CreateAccountbutton.Click += new System.EventHandler(this.CreateAccountbutton_Click);
            // 
            // bookmatepanel1
            // 
            this.bookmatepanel1.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.bookmatepanel1.Controls.Add(this.Bookmate);
            this.bookmatepanel1.Location = new System.Drawing.Point(-20, -2);
            this.bookmatepanel1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bookmatepanel1.Name = "bookmatepanel1";
            this.bookmatepanel1.Size = new System.Drawing.Size(1130, 58);
            this.bookmatepanel1.TabIndex = 8;
            // 
            // Bookmate
            // 
            this.Bookmate.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Bookmate.AutoSize = true;
            this.Bookmate.Location = new System.Drawing.Point(531, 23);
            this.Bookmate.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Bookmate.Name = "Bookmate";
            this.Bookmate.Size = new System.Drawing.Size(69, 16);
            this.Bookmate.TabIndex = 0;
            this.Bookmate.Text = "BookMate";
            // 
            // login
            // 
            this.login.Location = new System.Drawing.Point(10, 359);
            this.login.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.login.Name = "login";
            this.login.Size = new System.Drawing.Size(1074, 62);
            this.login.TabIndex = 7;
            this.login.Text = "Log In";
            this.login.UseVisualStyleBackColor = true;
            this.login.Click += new System.EventHandler(this.login_Click);
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new System.Drawing.Point(7, 344);
            this.linkLabel1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(0, 16);
            this.linkLabel1.TabIndex = 6;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.Info;
            this.pictureBox1.Image = global::bookmate.Properties.Resources._12;
            this.pictureBox1.Location = new System.Drawing.Point(10, 81);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1074, 267);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            // 
            // Starting
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1111, 544);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.CreateAccountbutton);
            this.Controls.Add(this.bookmatepanel1);
            this.Controls.Add(this.login);
            this.Controls.Add(this.linkLabel1);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Starting";
            this.Text = "Starting";
            this.bookmatepanel1.ResumeLayout(false);
            this.bookmatepanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button CreateAccountbutton;
        private System.Windows.Forms.Panel bookmatepanel1;
        private System.Windows.Forms.Label Bookmate;
        private System.Windows.Forms.Button login;
        private System.Windows.Forms.LinkLabel linkLabel1;
    }
}