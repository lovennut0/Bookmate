﻿namespace bookmate
{
    partial class signup
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Fillyourinformation = new System.Windows.Forms.Label();
            this.username = new System.Windows.Forms.Label();
            this.Namefill = new System.Windows.Forms.TextBox();
            this.personalidfill = new System.Windows.Forms.TextBox();
            this.password = new System.Windows.Forms.Label();
            this.Confirmpassword = new System.Windows.Forms.Label();
            this.signupbutton = new System.Windows.Forms.Button();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.email = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnBack = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Fillyourinformation
            // 
            this.Fillyourinformation.AutoSize = true;
            this.Fillyourinformation.Location = new System.Drawing.Point(45, 51);
            this.Fillyourinformation.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Fillyourinformation.Name = "Fillyourinformation";
            this.Fillyourinformation.Size = new System.Drawing.Size(121, 16);
            this.Fillyourinformation.TabIndex = 14;
            this.Fillyourinformation.Text = "Fill your information";
            // 
            // username
            // 
            this.username.AutoSize = true;
            this.username.Location = new System.Drawing.Point(104, 103);
            this.username.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.username.Name = "username";
            this.username.Size = new System.Drawing.Size(76, 16);
            this.username.TabIndex = 15;
            this.username.Text = "Username :";
            this.username.Click += new System.EventHandler(this.label3_Click);
            // 
            // Namefill
            // 
            this.Namefill.Location = new System.Drawing.Point(186, 92);
            this.Namefill.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Namefill.Multiline = true;
            this.Namefill.Name = "Namefill";
            this.Namefill.Size = new System.Drawing.Size(879, 39);
            this.Namefill.TabIndex = 16;
            // 
            // personalidfill
            // 
            this.personalidfill.Location = new System.Drawing.Point(189, 207);
            this.personalidfill.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.personalidfill.Multiline = true;
            this.personalidfill.Name = "personalidfill";
            this.personalidfill.Size = new System.Drawing.Size(879, 39);
            this.personalidfill.TabIndex = 18;
            // 
            // password
            // 
            this.password.AutoSize = true;
            this.password.Location = new System.Drawing.Point(106, 217);
            this.password.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.password.Name = "password";
            this.password.Size = new System.Drawing.Size(73, 16);
            this.password.TabIndex = 17;
            this.password.Text = "Password :";
            // 
            // Confirmpassword
            // 
            this.Confirmpassword.AutoSize = true;
            this.Confirmpassword.Location = new System.Drawing.Point(51, 278);
            this.Confirmpassword.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Confirmpassword.Name = "Confirmpassword";
            this.Confirmpassword.Size = new System.Drawing.Size(0, 16);
            this.Confirmpassword.TabIndex = 19;
            // 
            // signupbutton
            // 
            this.signupbutton.Location = new System.Drawing.Point(460, 330);
            this.signupbutton.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.signupbutton.Name = "signupbutton";
            this.signupbutton.Size = new System.Drawing.Size(243, 45);
            this.signupbutton.TabIndex = 21;
            this.signupbutton.Text = "Sign up";
            this.signupbutton.UseVisualStyleBackColor = true;
            this.signupbutton.Click += new System.EventHandler(this.signupbutton_Click);
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(186, 151);
            this.txtEmail.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtEmail.Multiline = true;
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(879, 39);
            this.txtEmail.TabIndex = 25;
            // 
            // email
            // 
            this.email.AutoSize = true;
            this.email.Location = new System.Drawing.Point(127, 160);
            this.email.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.email.Name = "email";
            this.email.Size = new System.Drawing.Size(47, 16);
            this.email.TabIndex = 24;
            this.email.Text = "Email :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(107, 206);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 16);
            this.label3.TabIndex = 22;
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnBack.Location = new System.Drawing.Point(25, 515);
            this.btnBack.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(93, 36);
            this.btnBack.TabIndex = 26;
            this.btnBack.Text = "<Back";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.button2_Click);
            // 
            // signup
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1144, 564);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.email);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.signupbutton);
            this.Controls.Add(this.Confirmpassword);
            this.Controls.Add(this.personalidfill);
            this.Controls.Add(this.password);
            this.Controls.Add(this.Namefill);
            this.Controls.Add(this.username);
            this.Controls.Add(this.Fillyourinformation);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "signup";
            this.Text = " sign up";
            this.Load += new System.EventHandler(this.signup_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label Fillyourinformation;
        private System.Windows.Forms.Label username;
        private System.Windows.Forms.TextBox Namefill;
        private System.Windows.Forms.TextBox personalidfill;
        private System.Windows.Forms.Label password;
        private System.Windows.Forms.Label Confirmpassword;
        private System.Windows.Forms.Button signupbutton;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label email;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnBack;
    }
}